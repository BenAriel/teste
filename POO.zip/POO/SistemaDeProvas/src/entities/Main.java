package entities;
//classe de teste das entidades, não faça o teste dos bancos de dados aqui!!!!
public class Main {

	public static void main(String[] args) {
		Monitor c1 = new Monitor("Vinícius", "Coxinha123", "Senha321", "1220901020");
		System.out.println(c1.toString());

	}

}
